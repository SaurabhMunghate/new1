﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Web;
using MySql.Data.MySqlClient;

namespace StudentDashbordMVC.Controllers
{
    public class User_list : Controller
    {
        public ActionResult Index()
        {
            string connectionString = "server=localhost;user=root;password=password;database=saurabh;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string sqlQuery = "SELECT * FROM User_Saurabh;";
                    MySqlCommand command = new MySqlCommand(sqlQuery, connection);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        var UserData = new UserDataModel();

                        while (reader.Read())
                        {

                            UserData.UserList.Add(new User
                            {
                                
                            });
                        }

                        return Json(UserData);
                    }
                }
                catch (Exception ex)
                {
                    return Content("An error occurred: " + ex.Message);
                }
            }
        }
    }

    public class User
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public byte[] Photo { get; set; }
        public string Gender { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string City { get; set; }
        public string ProfessionalSkills { get; set; }
    }


    public class UserDataModel
    {
        public List<User> UserList { get; set; }

        public UserDataModel()
        {
            UserList = new List<User>();
        }
    }
}