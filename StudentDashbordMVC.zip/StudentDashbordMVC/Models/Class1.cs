﻿namespace StudentDashbordMVC.Models
{
    public class Class1
    {
    }
}
