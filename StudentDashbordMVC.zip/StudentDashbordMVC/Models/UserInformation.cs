﻿namespace StudentDashbordMVC.Models
{
    public class UserInformation
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string FullName => $"{FirstName} {LastName}";

        public string PhotoUrl { get; set; }

        public GenderType Gender { get; set; }

        public string Email { get; set; }

        public string MobileNumber { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string City { get; set; }

        public List<string> ProfessionalSkills { get; set; }
    }

    public enum GenderType
    {
        Male,
        Female,
        Other
    }
}
